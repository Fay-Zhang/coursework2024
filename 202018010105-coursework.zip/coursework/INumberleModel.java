package coursework;

/**
 *
 * @author Fay
 */
import java.util.List;

public interface INumberleModel {
    int MAX_ATTEMPTS = 6;

    // Initializes the game
    void initialize();
    // Processes the input equation provided by the user
    boolean processInput(String input);
    // Checks if the game is over
    boolean isGameOver();
    // Checks if the game is won
    boolean isGameWon();
    // Gets the target number for the game
    String getTargetNumber();
    // Gets the current guess made by the player
    StringBuilder getCurrentGuess();
    // Gets the remaining attempts allowed in the game
    int getRemainingAttempts();
    // Starts a new game
    void startNewGame();
    // Sets the current guess based on generated equation
    void setCurrentGuess();
    // Checks the validity of the equation provided by the user
    String checkEquationValidity(String equation);
}