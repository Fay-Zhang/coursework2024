package coursework;

/**
 *
 * @author Fay
 */
import java.util.Scanner;

public class CLIApp {
    public static void main(String[] args) {
		// Initialize the Numberle model
    	INumberleModel model=new NumberleModel();
    	model.initialize();
		// Create a scanner object for user input
    	Scanner sc=new Scanner(System.in);
    	System.out.println("Welcome to the Numberle gaming system");
    	//Loop when the current RemainingAttempts value is greater than 0
    	while(model.getRemainingAttempts()>0) {
    		System.out.println("----Menu----");
    		System.out.println("Attempts remaining: "+model.getRemainingAttempts());
    		System.out.println("1.Display Equation");
    		System.out.println("2.Input Equation");
    		//When entering a valid equation once, the game can be restarted, allow game restart once after a valid equation has been entered
    		if(model.getRemainingAttempts()<6) {
    			System.out.println("3.Restart Game");
				System.out.println("4.Exit Game");
    		}
    		System.out.print("Please choose: ");
    		int choose=sc.nextInt();
    		//Display Equation
    		if(choose==1) {
    			System.out.println(model.getCurrentGuess());
    		}else if(choose==2) {//Input Equation
    			System.out.print("Please input Equation: ");
    			String equation=sc.next();
    			String check=model.checkEquationValidity(equation);
    			//Equation check passed and meets formatting requirements
    			if(check.equals("")) {
    				//Verify if two equations are consistent
    				model.processInput(equation);
					// Check game status
    				if(model.isGameWon()) {
    					System.out.println("Game over. You win!");
    					model.startNewGame();
        				model.setCurrentGuess();
        				System.out.println();
        				System.out.println("New Game");
    				}else if(model.isGameOver()) {//Lost the game and initialized it
    					System.out.println("Game over. You lost.");
    					model.startNewGame();
        				model.setCurrentGuess();
        				System.out.println();
        				System.out.println("New Game");
    				}else {//Guessing incorrectly but the game is not over
    					System.out.println("You guessed wrong");
                        for(int i=0;i<equation.length();i++) {
							char green, orange, gray;
							if(equation.charAt(i)==model.getCurrentGuess().charAt(i)) {
                                green = equation.charAt(i);
								System.out.println(green+"--------The character is correct.");
                            } else if(model.getCurrentGuess().toString().contains(String.valueOf(equation.charAt(i)))) {
                                orange = equation.charAt(i);
								System.out.println(orange+"--------The character is being used but in the wrong place.");
                            }else {
                                gray = equation.charAt(i);
								System.out.println(gray+"--------The character is not being used.");
                            }
                        }
    				}
    			}else {
    				System.out.println(check);
    			}
    		}else if(choose==3) {//When entering a valid equation once, the game can be restarted
    				model.startNewGame();
    				model.setCurrentGuess();
    				System.out.println();
    				System.out.println("New Game");
			}else if(choose==4) {
					System.exit(0);

			}else {
    			System.out.println("Input error, please re-enter");
    		}
    	}
    }
}
