package coursework;

/**
 *
 * @author Fay
 */
import javax.swing.*;
import javax.swing.border.LineBorder;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Observer;

public class NumberleView implements Observer {
    private final INumberleModel model;
    private final NumberleController controller;
    private final JFrame frame = new JFrame("Numberle");
    private final JLabel[][] inputLable = new JLabel[6][7];
    private final JButton[] buttons = new JButton[17];
    private final JLabel attemptsLabel = new JLabel("Attempts remaining: ");
//	private final JButton start = new JButton();
	private final JButton restart = new JButton("Restart");
	private final JButton assist = new JButton("Assist");
	private final JButton random = new JButton("Random");
	private final JButton answer = new JButton("Answer");
    private int row=0;//Current row
    private int col=0;//Current column
    String equation="";
	private boolean Assist = false;
	private boolean Random = false;

    public NumberleView(INumberleModel model, NumberleController controller) {
        this.controller = controller;
        this.model = model;
		// Start a new game when the view is initialized
        this.controller.startNewGame();
		// Register this view as an observer of the model
        ((NumberleModel)this.model).addObserver(this);
		// Initialize the GUI frame
		initializeFrame();
		// Set this view as the view of the controller
        this.controller.setView(this);
		// Update the view with the initial state of the model
        update((NumberleModel)this.model, null);
    }

    public void initializeFrame() {
		// Set the window close operation
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// Set the window size
		frame.setSize(585, 600);
		// Set the layout to null layout
        frame.setLayout(null);
		// Set the position and font style of the attempts remaining label
        attemptsLabel.setBounds(30, 10, 400, 30);
        attemptsLabel.setFont(new Font("Roman",Font.BOLD,20));
		// Add the attempts remaining label to the window
		frame.add(attemptsLabel);
		// Add input labels array to the window
        for(int i=0;i<inputLable.length;i++) {
        	for(int j=0;j<inputLable[i].length;j++) {
				// Set the border, horizontal alignment, and position of the input label
        		inputLable[i][j]=new JLabel();
        		inputLable[i][j].setBorder(new LineBorder(Color.black,2));
        		inputLable[i][j].setHorizontalAlignment(SwingConstants.CENTER);
        		inputLable[i][j].setBounds(75+j*60, 50+i*60, 55, 55);
        		inputLable[i][j].setOpaque(true);
				// Add the input label to the window
        		frame.add(inputLable[i][j]);
        	}
        }
		// Set the text array for buttons
        String key[]= {"1","2","3","4","5","6","7","8","9","0","Delete","+","-","*","/","=","Enter"};
		// Add number buttons to the window
		for(int i=0;i<10;i++) {
        	buttons[i]=new JButton(key[i]);
        	buttons[i].setBackground(Color.LIGHT_GRAY);
        	buttons[i].setBorder(null);
        	buttons[i].setBounds(10+i*55, 420, 50, 50);
            frame.add(buttons[i]);
        }
		// Add the Delete button to the window
        buttons[10]=new JButton(key[10]);
    	buttons[10].setBackground(Color.LIGHT_GRAY);
    	buttons[10].setBorder(null);
    	buttons[10].setBounds(10, 485, 105, 50);
        frame.add(buttons[10]);
		// Add operator buttons to the window
        for(int i=11;i<16;i++) {
        	buttons[i]=new JButton(key[i]);
        	buttons[i].setBackground(Color.LIGHT_GRAY);
        	buttons[i].setBorder(null);
        	buttons[i].setBounds(125+(i-11)*65, 485, 55, 50);
            frame.add(buttons[i]);
        }
		// Add the Enter button to the window
        buttons[16]=new JButton(key[16]);
    	buttons[16].setBackground(Color.LIGHT_GRAY);
    	buttons[16].setBorder(null);
    	buttons[16].setBounds(450, 485, 105, 50);
		// Add button click event handling
		clickButton();
		// Add the Enter button to the window
        frame.add(buttons[16]);
		frame.add(restart);
		assist.setBounds(270, 10, 60, 30);
		assist.setBackground(Color.LIGHT_GRAY);
		assist.setBorder(null);
		frame.add(assist);
		random.setBounds(340, 10, 60, 30);
		random.setBackground(Color.LIGHT_GRAY);
		random.setBorder(null);
		frame.add(random);
		answer.setBounds(410, 10, 60, 30);
		answer.setBackground(Color.LIGHT_GRAY);
		answer.setBorder(null);
		frame.add(answer);
		restart.setBounds(480, 10, 60, 30);
		restart.setBackground(Color.LIGHT_GRAY);
		restart.setBorder(null);
		restart.setEnabled(false);
		frame.add(restart);
		// Set the window visible
        frame.setVisible(true);
    }
    //Button click event
    public void clickButton() {
    	for(int i=0;i<17;i++) {
    		int x=i;
    		//Click the keyboard button
    		buttons[x].addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String title=buttons[x].getText();
					//Click Delete
					if(title.equals("Delete")) {
						if(col>0) {//Delete last character
							col--;
							inputLable[row][col].setText("");
						}
					}else if(title.equals("Enter")) {//Click Enter
						equation="";
						//Read input characters
						for (int i = 0; i < 7; i++) {
							equation += inputLable[row][i].getText();
						}
						String check = controller.checkEquationValidity(equation);
						//Equation check passed and meets formatting requirements
						if (check.equals("")) {
							restart.setEnabled(true);//Can restart the game
							controller.processInput(equation);//Verify if two equations are consistent
						} else {
							if (Assist == true) {
								// If validation fails, display error message
								Object[] option = {"Ok"};
								JOptionPane.showOptionDialog(null,
										"Equation error: " + check,
										"Message",
										JOptionPane.YES_NO_OPTION,
										JOptionPane.QUESTION_MESSAGE,
										null, option, option[0]);
							}else{
								restart.setEnabled(true);//Can restart the game
								controller.processInput(equation);//Verify if two equations are consistent
							}
						}
					}else {//Click on numbers and arithmetic symbols
						if(col<7) {
							inputLable[row][col].setText(title);
							col++;
						}
					}
				}
			});
    	}
		//When clicking the restart once, the game can be restarted
		restart.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				init();
			}
		});
		//When clicking the Assist once, the player will get help
		assist.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (Assist == false) {
					assist.setBackground(Color.GRAY);
					Assist = true;
				}else{
					assist.setBackground(Color.lightGray);
					Assist = false;
				}
			}
		});
		//When clicking the Random once, the game can be restarted and have deferent answer
		random.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (Random == false) {
					random.setBackground(Color.GRAY);
					Random = true;
				}else{
					random.setBackground(Color.lightGray);
					Random = false;
				}
			}
		});
		//Display answer
		answer.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				Object[] option = {"Ok"};
				JOptionPane.showOptionDialog(null,
						"Answer is: " + controller.getCurrentGuess(),
						"Message",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE,
						null, option, option[0]);
			}
		});
    }

    @Override
    public void update(java.util.Observable o, Object arg) {
		// Update the attempts remaining label with the current remaining attempts
		attemptsLabel.setText("Attempts remaining: " + controller.getRemainingAttempts());
		// Check if the game is won
		if (controller.isGameWon()) {
			// Display win message and options to restart or exit
			Object[] options = {"Restart", "Exit"};
			int result = JOptionPane.showOptionDialog(
					null,
					"You win!",
					"Game Over",
					JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE,
					null, options, options[0]
			);
			// Handle user choice
			if (result == 1) {
				System.exit(0);
			}
			init(); // Restart the game
		} else if (controller.isGameOver()) {
			// Check if the game is lost
			// Display loss message and options to restart or exit
			Object[] options = {"Restart", "Exit"};
			int result = JOptionPane.showOptionDialog(
					null,
					"You lost.",
					"Game Over",
					JOptionPane.YES_NO_OPTION,
					JOptionPane.QUESTION_MESSAGE,
					null, options, options[0]
			);
			// Handle user choice
			if (result == 1) {
				System.exit(0);
			}
			init(); // Restart the game
		} else if (controller.getRemainingAttempts() < 6) { // Guessing incorrectly but the game is not over
			// Set color for the equation
			setColor(equation);
			if (controller.getRemainingAttempts() > 1) {
				// If more than one attempt left, display options to show answer, start a new game, or continue
				Object[] options = {"Answer", "New Game", "Go on"};
				int n = JOptionPane.showOptionDialog(
						null,
						"You've got " + controller.getRemainingAttempts() + " more chances.",
						"You guessed wrong",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE,
						null, options, options[0]);
				// Handle user choice
				if (n == 0) {
					Object[] option = {"Ok"};
					JOptionPane.showOptionDialog(null,
							"Answer is: " + controller.getCurrentGuess(),
							"Message",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null, option, option[0]);
					col = 0;
					row++;
				} else if (n == 1) {
					init(); // Restart the game
				}else{
					col = 0;
					row++;
				}
			} else {
				// If only one attempt left, display options to show answer, start a new game, or go on
				Object[] options = {"Answer", "New Game", "Go On"};
				int n = JOptionPane.showOptionDialog(null,
						"You've got " + controller.getRemainingAttempts() + " more chance.",
						"You guessed wrong",
						JOptionPane.YES_NO_OPTION,
						JOptionPane.QUESTION_MESSAGE,
						null, options, options[0]);
				// Handle user choice
				if (n == 0) {
					Object[] option = {"Ok"};
					JOptionPane.showOptionDialog(null,
							"Answer is: " + controller.getCurrentGuess(),
							"Message",
							JOptionPane.YES_NO_OPTION,
							JOptionPane.QUESTION_MESSAGE,
							null, option, option[0]);
					col = 0;
					row++;
				} else if (n == 1) {
					init(); // Restart the game
				}else{
					col = 0;
					row++;
				}
			}
		}

    }

	//Start a new game
    public void init() {
    	row=0;
    	col=0;
		// Reset input labels
    	for(int i=0;i<inputLable.length;i++) {
    		for(int j=0;j<inputLable[i].length;j++) {
    			inputLable[i][j].setBackground(null);
    			inputLable[i][j].setText("");
    		}
    	}
		// Reset button colors
    	for(int i=0;i<buttons.length;i++) {
    		buttons[i].setBackground(Color.LIGHT_GRAY);
    	}
		controller.getRemainingAttempts();
		// Start a new game and set the current guess
		if (Random == true){
    	    controller.startNewGame();
    	    controller.setCurrentGuess();
		}else{
			model.initialize();
		}
		// Update the attempts remaining label with the current remaining attempts
		attemptsLabel.setText("Attempts remaining: " + controller.getRemainingAttempts());
    }

    //Set button color
    public void setColor(String equation) {
		for(int i=0;i<equation.length();i++) {
			//Set the button with the correct position to green
			if(equation.charAt(i)==controller.getCurrentGuess().charAt(i)) {
				inputLable[row][i].setBackground(Color.GREEN);
				for(int j=0;j<17;j++) {
					if(buttons[j].getText().equals(String.valueOf(equation.charAt(i)))) {
						buttons[j].setBackground(Color.GREEN);
					}
				}
			}
			//The button with incorrect position is set to orange
			else if(controller.getCurrentGuess().toString().contains(String.valueOf(equation.charAt(i)))) {
				inputLable[row][i].setBackground(Color.ORANGE);
				for(int j=0;j<17;j++) {
					if(buttons[j].getText().equals(String.valueOf(equation.charAt(i)))) {
						buttons[j].setBackground(Color.ORANGE);
					}
				}													
			}
			//Set non-existent buttons to gray
			else {
				inputLable[row][i].setBackground(Color.GRAY);
				for(int j=0;j<17;j++) {
					if(buttons[j].getText().equals(String.valueOf(equation.charAt(i)))) {
						buttons[j].setBackground(Color.GRAY);
					}
				}	
			}
		}
    }
}