package coursework;

/**
 *
 * @author Fay
 */
public class NumberleController {
    private INumberleModel model;
    private NumberleView view;

    // Constructor to initialize with a model
    public NumberleController(INumberleModel model) {
        this.model = model;
    }

    // Method to set the associated view
    public void setView(NumberleView view) {
        this.view = view;
    }

    // Method to process user input
    public void processInput(String input) {
        model.processInput(input);
    }

    // Method to check if the game is over
    public boolean isGameOver() {
        return model.isGameOver();
    }

    // Method to check if the game is won
    public boolean isGameWon() {
        return model.isGameWon();
    }

    // Method to get the current guess made by the player
    public StringBuilder getCurrentGuess() {
        return model.getCurrentGuess();
    }

    // Method to get the remaining attempts allowed in the game
    public int getRemainingAttempts() {
        return model.getRemainingAttempts();
    }

    // Method to start a new game
    public void startNewGame() {
        model.startNewGame();
    }

    // Method to check the validity of the equation provided by the user
    public String checkEquationValidity(String equation) {
        return model.checkEquationValidity(equation);
    }

    // Method to set the current guess based on generated equation
    public void setCurrentGuess() {
        model.setCurrentGuess();
    }
}