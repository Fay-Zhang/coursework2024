package coursework;

/*
 *
 * @author Fay
 */
import java.util.Random;
import java.util.Stack;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;

public class NumberleModel extends Observable implements INumberleModel {
    private String targetNumber;
    private StringBuilder currentGuess;
    private int remainingAttempts;
    private boolean gameWon;

    @Override
    /**
     * Initializes the game by generating a random target number, setting the default current guess,
     * and resetting the remaining attempts and game status.
     *
     @ensures The game is initialized with a random target number, default current guess,
              maximum remaining attempts, and game status indicating not won.
     */
    public void initialize() {
        Random rand = new Random();
        targetNumber = Integer.toString(rand.nextInt(10000000));
        // Set the default current guess
        currentGuess = new StringBuilder("1+2-3=0");
        // Set the remaining attempts to the maximum allowed attempts
        remainingAttempts = MAX_ATTEMPTS;
        // Set the game status to indicate that the game has not been won yet
        gameWon = false;

//        setChanged();
//        notifyObservers();
    }

    @Override
    /**
     * Processes the user input by comparing it with the current guessing equation.
     * If the input equation matches the current guessing equation:
     *   - Sets gameWon to true.
     *   - Notifies observers.
     *   - Returns true.
     * If the input equation does not match the current guessing equation:
     *   - Decrements remainingAttempts.
     *   - Notifies observers.
     *   - Returns false.
     *
     @param input The equation entered by the user.
     @return true if the input equation matches the current guessing equation, false otherwise.
     @requires input != null
     @ensures
          - If the input equation matches the current guessing equation:
              - gameWon is set to true.
              - Observers are notified.
              - Returns true.
          - If the input equation does not match the current guessing equation:
              - remainingAttempts is decremented.
              - Observers are notified.
              - Returns false.
     */
    public boolean processInput(String input) {
        // Ensure that the input is not null
        assert input != null : "Input must not be null";

        // Check if the input equation matches the current guessing equation
        boolean result;
    	if(input.equals(currentGuess.toString())) {
            // If matches, set gameWon to true, notify observers, and return true
    		gameWon = true;
    		setChanged();
            notifyObservers();
            result = true;
    	}else {
            // If doesn't match, decrement remainingAttempts, notify observers, and return false
    		remainingAttempts--;
            setChanged();
            notifyObservers();
            result = false;
    	}

        // Ensure that remaining attempts is non-negative
        assert remainingAttempts >= 0 : "Remaining attempts should be non-negative";

        return result;
    }

    @Override
    /**
     * Checks if the game is over.
     @return true if the game is over (either remainingAttempts is less than or equal to 0 or gameWon is true), false otherwise.
     */
    public boolean isGameOver() {

        // Ensure that remaining attempts is non-negative
        assert remainingAttempts >= 0 : "Remaining attempts should be non-negative";

        // Check if the game is over (either remainingAttempts is less than or equal to 0 or gameWon is true)
        boolean result = remainingAttempts <= 0 || gameWon;

        //Ensure result is a boolean
        assert result == true || result == false: "result is not a boolean";

        return result;
    }

    @Override
    public boolean isGameWon() {
        //Checks if the game has been won.
        //return true if the game has been won, false otherwise.
        return gameWon;
    }

    @Override
    public String getTargetNumber() {
        //Returns the target number of the game.
        return targetNumber;
    }

    @Override
    public StringBuilder getCurrentGuess() {
        //Returns the current guess of the player.
        return currentGuess;
    }

    @Override
    public int getRemainingAttempts() {
        //Returns the number of remaining attempts in the game.
        return remainingAttempts;
    }

    @Override
    /**
     * Starts a new game by initializing game parameters.
     @ensure The game parameters are initialized.
     @invariant The game parameters are valid after initialization.
     */
    public void startNewGame() {
        initialize();
    }

    /**
     * Retrieves an equation from a file and returns it as a StringBuilder object.
     *
     @return a StringBuilder object representing an equation retrieved from a file.
     @requires The file "src/equations.txt" exists and contains valid equations.
     @ensures The returned StringBuilder object contains a valid equation from the file.
     */
    public StringBuilder getEquation() {
        // Create a list to store equations
    	ArrayList<String> list=new ArrayList<String>();
    	BufferedReader br = null;
        try {
            // Read equations from the file and add them to the list
            br = new BufferedReader(new FileReader("src/equations.txt"));
            String line = null;
            while ((line = br.readLine()) != null) {
            	list.add(line);
            }
        } catch (FileNotFoundException e) {
            // Handle file not found exception
        	e.printStackTrace();
        } catch (IOException e) {
            // Handle IO exception
            e.printStackTrace();
        }

        // Ensure that the list of equations is not empty
        assert !list.isEmpty() : "Equation list must not be empty";

        // Select a random equation from the list and return it as a StringBuilder object
        return new StringBuilder(list.get(new Random().nextInt(list.size())));
    }

	@Override
    /**
     * Sets the current guess by retrieving an equation from a file and assigning it to the current guess.
     * The new current guess replaces the previous one.
     *
     @requires The file "src/equations.txt" exists and contains valid equations.
     @ensures The current guess is set to a valid equation retrieved from the file.
     */
	public void setCurrentGuess() {
        //Sets the current guess by retrieving an equation from a file and assigning it to the current guess.
		this.currentGuess=getEquation();
	}
	@Override
    /**
     * Checks the validity of an equation.
     *
     @param equation The equation to be checked.
     @return a String indicating the validity of the equation:
       - "Too short" if the equation length is not equal to 7.
       - "Multiple math symbols in a row" if there are consecutive arithmetic operators.
       - "No equal sign" if the equation does not contain an equal sign.
       - "There must be at least one sign" if the equation does not contain any arithmetic symbols.
       - "The equations on both sides are not equal" if the equations on both sides of the equal sign are not equal.
       - Empty string ("") if the equation is valid.
     @requires equation != null
     @ensures The returned string indicates the validity of the equation.
     */
    public String checkEquationValidity(String equation) {

        // Ensure that the equation is not null
        assert equation != null : "Equation must not be null";

        // Check the length of the equation
        if (equation.length() != 7) {
            return "Too short";
        }

        //Determine if there are consecutive arithmetic operators present
        String operators = "+-*/=";
        boolean lastWasOperator = false;
        for (char c : equation.toCharArray()) {
            boolean isOperator = operators.indexOf(c) != -1;
            if (isOperator && lastWasOperator) {
                return "Multiple math symbols in a row";
            }
            lastWasOperator = isOperator;
        }
        //Determine if it contains an equal sign
        if (!equation.contains("=")) {
            return "No equal '=' sign";
        }
        //Determine if it contains arithmetic symbols
        if (!equation.contains("+") && !equation.contains("-") && !equation.contains("*") && !equation.contains("/")) {
            return "There are must be at least one sign\"+-*/\"";
        }

        String[] expression = equation.split("=");

        double left = calculateExpression(expression[0]);
        double right = calculateExpression(expression[1]);

        //The equations on both sides are not equal
        if (left != right) {
            return "The equations on both sides are not equal";
        }
        //All checks passed, return ""
        return "";
    }

    /**
     * Calculates the result of a mathematical expression.
     *
     @param expression The mathematical expression to be evaluated.
     @return the result of the mathematical expression.
     @requires expression != null
     @ensures The returned value is the result of evaluating the expression.
     */
    public static double calculateExpression(String expression) {

        // Ensure that the expression is not null
        assert expression != null : "Expression must not be null";

        // Initialize stacks to store numbers and operators
        Stack<Double> numbers = new Stack<>();
        Stack<Character> operators = new Stack<>();
        StringBuilder number = new StringBuilder();

        // Iterate through each character in the expression
        for (char ch : expression.toCharArray()) {
            if (Character.isDigit(ch)) {
            	//If the character is a number, append it to the current number string
                number.append(ch);
            } else {
            	//If the character is an operator or the end of an expression, perform the calculation
                numbers.push(Double.parseDouble(number.toString()));
                number.setLength(0);
                //If the operator stack is not empty and the top operator priority is higher than or equal to the current operator (or if the stack is empty)
                //Then perform the operation until a higher priority operator is found or the stack is empty
                while (!operators.isEmpty() && hasPrecedence(ch, operators.peek())) {

                    assert numbers.size() >= 2 : "Insufficient operators to perform operation";

                    numbers.push(operate(operators.pop(), numbers.pop(), numbers.pop()));
                }
                // Push the current operator onto the stack
                operators.push(ch);
            }
        }
        //Handle the last number and remaining operators
        numbers.push(Double.parseDouble(number.toString()));
        while (!operators.isEmpty()) {

            assert numbers.size() >= 2 : "Insufficient operators to perform operation";

            numbers.push(operate(operators.pop(), numbers.pop(), numbers.pop()));
        }
        return numbers.pop();
    }

    /**
     * Determines if one operator has higher precedence than another.
     *
     @param op1 The first operator.
     @param op2 The second operator.
     @return true if op1 has higher precedence than op2, false otherwise.
     @requires op1 and op2 are valid arithmetic operators ('+', '-', '*', '/').
     @ensures The returned value indicates whether op1 has higher precedence than op2.
     */
    private static boolean hasPrecedence(char op1, char op2) {
        // Check if op1 has higher precedence than op2 based on operator priority
        if ((op1 == '*' || op1 == '/') && (op2 == '+' || op2 == '-')) return false;
        return true;
    }

    /**
     * Performs arithmetic operation based on the specified operator and operands.
     *
     @param op The operator specifying the arithmetic operation.
     @param b The second operand.
     @param a The first operand.
     @return the result of the arithmetic operation.
     @requires op is a valid arithmetic operator ('+', '-', '*', '/').
     @ensures The returned value is the result of performing the arithmetic operation.
     */
    private static double operate(char op, double b, double a) {
        // Perform arithmetic operation based on the specified operator
        switch (op) {
            case '+': return a + b;
            case '-': return a - b;
            case '*': return a * b;
            case '/': return a / b;
        }
        // Default case: return 0 if operator is not recognized
        return 0;
    }
}
