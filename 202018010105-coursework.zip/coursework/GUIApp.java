package coursework;

/**
 *
 * @author Fay
 */
import javax.swing.*;

public class GUIApp {
    public static void main(String[] args) {
        // Run the GUI creation on the event dispatch thread
        SwingUtilities.invokeLater(
                new Runnable() {
                    public void run() {
                        createAndShowGUI();
                    }
                }
        );
    }

    public static void createAndShowGUI() {
        // Create the Numberle model, controller, and view
        INumberleModel model = new NumberleModel();
        NumberleController controller = new NumberleController(model);
        NumberleView view = new NumberleView(model, controller);
    }
}