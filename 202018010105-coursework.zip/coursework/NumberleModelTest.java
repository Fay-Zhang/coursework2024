package coursework;

/**
 *
 * @author Fay
 */
import org.junit.Test;
import static org.junit.Assert.*;


public class NumberleModelTest {
    INumberleModel model=new NumberleModel();

    @Test
    public void processInputTest() {
        //Input correct answer, the new game will start, remaining attempts was updated to 6
        model.startNewGame();
        model.processInput("1+2-3=0");
        assertEquals(6, model.getRemainingAttempts());
    }

    @Test
    public void isGameOverTest() {
        //Input 6 incorrect equations in the game, it should be the end of the game
        model.startNewGame();
        for(int i=0;i<6;i++) {
            model.processInput("1+1+1=3");
        }
        assertTrue("Game Over",model.isGameOver());
    }

    @Test
    public void isGameWonTest() {
        model.initialize();
        //Enter the correct equation in the game to win the game
        model.processInput("1+2-3=0");
        assertTrue("Game Won",model.isGameWon());
    }
}
